package org.example;

public interface WindowConstants {

    int WIDTH = 640;
    int HEIGHT = 480;
}
